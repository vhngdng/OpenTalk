package com.example.demo.entity.UserRole;

import com.example.demo.entity.Employee;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Entity
@Data

@NoArgsConstructor
@Table(name = "role")
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private Integer id;
    @Column(name = "role", nullable = false, unique = true)
    private String name;

//    @ManyToMany(mappedBy = "roles")
//    private Collection<Employee> employees = new ArrayList<>();

    public Role(String role) {
        this.name = role;
    }
}
