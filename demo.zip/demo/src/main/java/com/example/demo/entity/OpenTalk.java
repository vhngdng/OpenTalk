package com.example.demo.entity;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;

@Entity
@NoArgsConstructor
@Data
@Table(name = "openTalk")

public class OpenTalk {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private Long id;
    @Column(name = "topic_title")
    private String topicName;
    @Column(name = "time")
//    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-DD HH:mm:ss")
    private LocalDateTime time;
    @Column(name = "link_meeting", nullable = false)
    private String linkMeeting;

//    @OneToOne(fetch = FetchType.LAZY,
//            cascade = {CascadeType.ALL},
//            orphanRemoval = true,
//            mappedBy = "openTalk"
//    )
////    @JoinColumn(name = "host_id")
//    private HostOpenTalk hostOpenTalk;

    @ManyToOne(fetch = FetchType.LAZY,
            cascade = {CascadeType.DETACH, CascadeType.PERSIST,
                     CascadeType.MERGE, CascadeType.REFRESH})
    @JoinTable(name = "opentalk_employee",
            joinColumns =
                    {@JoinColumn(name = "opentalk_id", referencedColumnName = "id")},
            inverseJoinColumns =
                    {@JoinColumn(name = "employee_id", referencedColumnName = "id")})
//    @JsonIgnoreProperties("openTalks")
    private Employee employee;
    @ManyToOne(fetch = FetchType.EAGER,
            cascade = {CascadeType.DETACH, CascadeType.MERGE,
                    CascadeType.PERSIST, CascadeType.REFRESH})
    @JoinColumn(name = "branch_id", nullable = false)             // open talks - branch
    private Branch branch;



    public OpenTalk(String topicName, LocalDateTime time, String linkMeeting, Employee employee, Branch branch) {
        this.topicName = topicName;
        this.time = time;
        this.linkMeeting = linkMeeting;
        this.employee = employee;
        this.branch = branch;
    }


}
