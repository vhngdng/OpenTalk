package com.example.demo.service;

import com.example.demo.dto.Display.AccountDisplayDTO;
import com.example.demo.dto.EmployeeDTO;
import com.example.demo.entity.Employee;
import com.example.demo.entity.UserRole.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface IEmployeeService {
    EmployeeDTO findById(long id);
    EmployeeDTO save(EmployeeDTO employeeDTO);
    List<EmployeeDTO> findAllEmployees();

    Page<EmployeeDTO> findAllWithPagination(Integer limit, Integer page);

    List<AccountDisplayDTO> findAllAccount();

    ResponseEntity<Void> deleteById(long id);

    boolean duplicateName(String name);

    boolean duplicateEmail(String email);

    Role saveRole(Role role);
    void addRoleToUser(String username, String roleName);

    ResponseEntity<List<EmployeeDTO>> findAllAdminAccount();
}
