package com.example.demo;

import com.github.javafaker.Faker;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.config.annotation.authentication.configurers.userdetails.UserDetailsAwareConfigurer;

@SpringBootApplication(
        scanBasePackages = "com.example.demo",
        exclude = {SecurityAutoConfiguration.class,
                UserDetailsServiceAutoConfiguration.class })
//@EnableConfigurationProperties
public class OpenTalkApp {

    public static void main(String[] args) {
        SpringApplication.run(OpenTalkApp.class, args);
    }

    @Bean
    public Faker faker () {
        return new Faker();
    }
}


