package com.example.demo.Jwt.UserDetailServiceImpl;


import com.example.demo.config.UserPrinciple;
import com.example.demo.entity.Employee;
import com.example.demo.entity.UserRole.Role;
import com.example.demo.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CustomUserDetailService implements UserDetailsService {

    private final EmployeeRepository employeeRepository;

    private final Logger logger = LoggerFactory.getLogger(CustomUserDetailService.class);

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        logger.info("============================================================" + username);
        Employee employee = employeeRepository.findByUserName(username);
        System.out.println(employee.getUserName());
//                .orElseThrow(() -> new UsernameNotFoundException("Username not found with username or email " + username));
        logger.info(employee.toString());
        UserPrinciple userPrinciple = new UserPrinciple(employee.getUserName(), employee.getPassword(), mapRolesToAuthorities(employee.getRoles()));
        logger.info(userPrinciple.getUsername());
        return userPrinciple;
//        return new UserPrinciple(employee.getUserName(), employee.getPassword(), mapRolesToAuthorities(employee.getRoles()));
//                new org.springframework.security.core.userdetails.User(employee.getUserName(), employee.getPassword(), mapRolesToAuthorities(employee.getRoles()));
    }

    private Collection< ? extends GrantedAuthority> mapRolesToAuthorities(Set<Role> roles){
        return roles.stream().map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());
    }
}
