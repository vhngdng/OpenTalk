package com.example.demo.config;

import com.example.demo.Jwt.UserDetailServiceImpl.CustomUserDetailService;
import lombok.RequiredArgsConstructor;
import org.mapstruct.control.MappingControl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@EnableWebSecurity
@RequiredArgsConstructor
public class WebSecurityConfig {
    //        private final UserDetailsService userDetailsService;

//    private final AuthenticationManager authenticationManager;
//    private final AuthenticationConfiguration authenticationConfiguration;
//    @Bean
//    public Auth
    private final CustomUserDetailService customUserDetailService;

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }


    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(requests -> {
                            try {
                                requests

                                        .antMatchers("/login")
                                        .permitAll()
                                        .antMatchers("/employee/**")
                                        .hasAnyRole("EMPLOYEE", "ADMIN")
                                        .antMatchers("/admin/**")
                                        .hasRole("ADMIN")
                                        .anyRequest()
                                        .authenticated()
                                        .and()
                                        .csrf()
                                        .disable()
                                ;
//                                http.addFilterBefore(authe)
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        });
//                        .authenticated()

//                .formLogin(form -> form.loginPage("/login").usernameParameter("email").permitAll())
//                .httpBasic(Customizer.withDefaults());

//                .oauth2ResourceServer().jwt();
//                .logout(LogoutConfigurer::permitAll)
//                .oauth2ResourceServer().jwt();


        return http.build();
    }
//        http.authorizeHttpRequests().antMatchers("/**").permitAll().and().csrf().disable();
//                .cors().and().authorizeRequests().anyRequest().permitAll();
//        return http.build();


    //
//    @Bean
//    public UserDetailsService userDetailsService(BCryptPasswordEncoder bCryptPasswordEncoder) {
//        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
//        manager.createUser(User.withUsername("employee")
//                .password(bCryptPasswordEncoder.encode("password"))
//                .roles("EMPLOYEE")
//                .build());
//        manager.createUser(User.withUsername("admin")
//                .password(bCryptPasswordEncoder.encode("admin"))
//                .roles("EMPLOYEE", "ADMIN")
//                .build());
//        return manager;
//        UserDetails user = User.withUsername("user")
//                .password("password")
//                .roles("ADMIN")
//                .build();
//        return new InMemoryUserDetailsManager(user);
//    }

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring().antMatchers("/images/**", "/js/**", "/webjars/**");
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

//    @Bean
//    public AuthenticationManager authManager(HttpSecurity http) throws Exception {
//        return http.getSharedObject(AuthenticationManagerBuilder.class)
//                .userDetailsService(customUserDetailService)
//                .and()
//                .build();
//    }
}
