package com.example.demo.entity;

import com.example.demo.entity.UserRole.Role;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.util.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "employee")
public class Employee{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column()
    private Long id;
    @Column(name = "username", length = 64, nullable = false, unique = true)
    private String userName;

    @Column(name = "full_name", length = 64, nullable = false)
    private String fullName;

    @Column(name = "email", length = 64, nullable = false, unique = true)
    @Email
    private String email;
    @Column(name = "password", length = 64, nullable = false)
    private String password;

    @ManyToMany(fetch = FetchType.EAGER,
            cascade = {CascadeType.DETACH,
                    CascadeType.PERSIST, CascadeType.REFRESH})

    @JoinTable(name = "user_role",
            joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id")
    )
    private Set<Role> roles = new HashSet<>();

    @OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
    private List<OpenTalk> openTalks;

    @Column(columnDefinition = "boolean default true")
    private boolean active;


    @ManyToOne(fetch = FetchType.EAGER,
            cascade = CascadeType.ALL)
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;


//    @OneToOne(mappedBy = "employee",
//            cascade = {CascadeType.DETACH, CascadeType.MERGE,
//                    CascadeType.PERSIST, CascadeType.REFRESH})
//    private HostOpenTalk hostOpenTalk;


//    public Employee(String userName, String fullName, String email, String password) {
//        this.userName = userName;
//        this.fullName = fullName;
//        this.email = email;
//        this.password = password;
//
//    }

    public Employee(String userName, String fullName, String email, String password, Set<Role> roles, boolean active, Branch branch) {
        this.userName = userName;
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.roles = roles;
        this.active = active;
        this.branch = branch;
    }



}